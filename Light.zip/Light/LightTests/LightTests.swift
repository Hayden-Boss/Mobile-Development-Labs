//
//  LightTests.swift
//  LightTests
//
//  Created by Hayden Boss on 1/31/25.
//

import Testing
@testable import Light

struct LightTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
